describe("Operation validateFirstname",()=>
{
    it("test validateFirstname() with Valid input",()=>
    {
    expect(validateFirstname ("PrateekUP")).toEqual("")
});

it("test validateFirstname() with Valid input",()=>
    {
    expect(validateFirstname ("Prateek09UP")).toEqual("Only Alphabets use")
});

})
